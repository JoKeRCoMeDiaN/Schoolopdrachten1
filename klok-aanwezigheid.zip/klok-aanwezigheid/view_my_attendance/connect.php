<?php
	$conn = new mysqli('localhost', 'root', '','attendance_sys') or die("Database Connection Failed");